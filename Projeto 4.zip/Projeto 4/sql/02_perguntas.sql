
-- PROJETO SENAI: ANÁLISE DE DADOS COM PYTHON E POSTGRESQL
-- Perguntas de negócio da Controladoria
-- Base: Contratações públicas do PNCP - ano de 2025


-- 1. ECONOMIA GLOBAL DO PODER PÚBLICO
-- Considera apenas itens comparáveis para calcular a economia.

SELECT
    SUM(CASE WHEN comparavel = 1
        THEN valor_total_estimado ELSE 0 END) AS estimado_comparavel,

    SUM(CASE WHEN comparavel = 1
        THEN valor_total_homologado ELSE 0 END) AS homologado_comparavel,

    SUM(CASE WHEN comparavel = 1
        THEN valor_total_estimado - valor_total_homologado
        ELSE 0 END) AS economia_valor,

    ROUND(
        100.0 * SUM(CASE WHEN comparavel = 1
            THEN valor_total_estimado - valor_total_homologado
            ELSE 0 END)
        / NULLIF(SUM(CASE WHEN comparavel = 1
            THEN valor_total_estimado ELSE 0 END), 0),
        2
    ) AS economia_percentual

FROM fato_item_contratado;


-- 2. CONCENTRAÇÃO E RISCO DE FORNECEDORES
-- Os dez fornecedores com maior volume homologado e sua participação
-- no valor total das contratações.

WITH total AS (
    SELECT SUM(valor_total_homologado) AS valor_total
    FROM fato_item_contratado
)
SELECT
    f.ni_fornecedor,
    f.nome_fornecedor,
    SUM(ft.valor_total_homologado) AS volume_homologado,
    ROUND(
        100.0 * SUM(ft.valor_total_homologado)
        / NULLIF((SELECT valor_total FROM total), 0),
        2
    ) AS percentual_do_total
FROM fato_item_contratado ft
JOIN dim_fornecedor f
    ON ft.sk_fornecedor = f.sk_fornecedor
GROUP BY f.ni_fornecedor, f.nome_fornecedor
ORDER BY volume_homologado DESC
LIMIT 10;


-- 3. EFICÁCIA POR MODALIDADE
-- Volume financeiro e percentual de economia por modalidade.

SELECT
    m.nome_modalidade,
    SUM(ft.valor_total_homologado) AS volume_homologado,

    SUM(CASE WHEN ft.comparavel = 1
        THEN ft.valor_total_estimado ELSE 0 END) AS estimado_comparavel,

    SUM(CASE WHEN ft.comparavel = 1
        THEN ft.valor_total_estimado - ft.valor_total_homologado
        ELSE 0 END) AS economia_valor,

    ROUND(
        100.0 * SUM(CASE WHEN ft.comparavel = 1
            THEN ft.valor_total_estimado - ft.valor_total_homologado
            ELSE 0 END)
        / NULLIF(SUM(CASE WHEN ft.comparavel = 1
            THEN ft.valor_total_estimado ELSE 0 END), 0),
        2
    ) AS economia_percentual

FROM fato_item_contratado ft
JOIN dim_modalidade m
    ON ft.sk_modalidade = m.sk_modalidade
GROUP BY m.nome_modalidade
ORDER BY volume_homologado DESC;


-- 4. TEMPO DO CICLO DE COMPRAS POR ÓRGÃO
-- Considera apenas itens com ciclo calculado e órgãos com cinco ou
-- mais itens com ciclo.

SELECT
    o.nome_orgao,
    COUNT(ft.dias_ciclo) AS itens_com_ciclo,
    ROUND(AVG(ft.dias_ciclo), 1) AS media_dias_ciclo
FROM fato_item_contratado ft
JOIN dim_orgao o
    ON ft.sk_orgao = o.sk_orgao
WHERE ft.dias_ciclo IS NOT NULL
GROUP BY o.nome_orgao
HAVING COUNT(ft.dias_ciclo) >= 5
ORDER BY media_dias_ciclo DESC;


-- 5A. DISTRIBUIÇÃO REGIONAL POR ESTADO
-- Despesas homologadas e economia percentual por UF.

SELECT
    l.uf_sigla,
    l.uf_nome,
    l.regiao,
    SUM(ft.valor_total_homologado) AS volume_homologado,

    ROUND(
        100.0 * SUM(CASE WHEN ft.comparavel = 1
            THEN ft.valor_total_estimado - ft.valor_total_homologado
            ELSE 0 END)
        / NULLIF(SUM(CASE WHEN ft.comparavel = 1
            THEN ft.valor_total_estimado ELSE 0 END), 0),
        2
    ) AS economia_percentual

FROM fato_item_contratado ft
JOIN dim_localidade l
    ON ft.sk_localidade = l.sk_localidade
GROUP BY l.uf_sigla, l.uf_nome, l.regiao
ORDER BY volume_homologado DESC;


-- 5B. DISTRIBUIÇÃO REGIONAL POR REGIÃO
-- Compara o volume homologado e a economia percentual entre regiões.

SELECT
    l.regiao,
    SUM(ft.valor_total_homologado) AS volume_homologado,

    ROUND(
        100.0 * SUM(CASE WHEN ft.comparavel = 1
            THEN ft.valor_total_estimado - ft.valor_total_homologado
            ELSE 0 END)
        / NULLIF(SUM(CASE WHEN ft.comparavel = 1
            THEN ft.valor_total_estimado ELSE 0 END), 0),
        2
    ) AS economia_percentual

FROM fato_item_contratado ft
JOIN dim_localidade l
    ON ft.sk_localidade = l.sk_localidade
GROUP BY l.regiao
ORDER BY volume_homologado DESC;


-- 6. PERFIL DOS GASTOS
-- Distribuição das despesas homologadas entre bens, serviços e obras.

SELECT
    perfil_gasto,
    SUM(valor_total_homologado) AS volume_homologado,

    ROUND(
        100.0 * SUM(valor_total_homologado)
        / NULLIF((SELECT SUM(valor_total_homologado)
                  FROM fato_item_contratado), 0),
        2
    ) AS percentual_do_total

FROM fato_item_contratado
GROUP BY perfil_gasto
ORDER BY volume_homologado DESC;
