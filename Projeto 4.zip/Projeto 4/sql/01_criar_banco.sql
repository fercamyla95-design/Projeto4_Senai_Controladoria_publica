
CREATE TABLE dim_orgao (
    sk_orgao INTEGER PRIMARY KEY,
    cnpj_orgao VARCHAR(14) NOT NULL UNIQUE,
    nome_orgao TEXT,
    poder TEXT
);

CREATE TABLE dim_fornecedor (
    sk_fornecedor INTEGER PRIMARY KEY,
    ni_fornecedor VARCHAR(20) NOT NULL UNIQUE,
    nome_fornecedor TEXT,
    tipo_pessoa TEXT,
    porte TEXT
);

CREATE TABLE dim_modalidade (
    sk_modalidade INTEGER PRIMARY KEY,
    modalidade_id INTEGER NOT NULL UNIQUE,
    nome_modalidade TEXT
);

CREATE TABLE dim_localidade (
    sk_localidade INTEGER PRIMARY KEY,
    uf_sigla CHAR(2) NOT NULL UNIQUE,
    uf_nome TEXT,
    regiao TEXT
);

CREATE TABLE fato_item_contratado (
    numero_controle_pncp VARCHAR(30) NOT NULL,
    numero_item INTEGER NOT NULL CHECK (numero_item > 0),

    sk_orgao INTEGER NOT NULL REFERENCES dim_orgao(sk_orgao),
    sk_fornecedor INTEGER NOT NULL REFERENCES dim_fornecedor(sk_fornecedor),
    sk_modalidade INTEGER NOT NULL REFERENCES dim_modalidade(sk_modalidade),
    sk_localidade INTEGER NOT NULL REFERENCES dim_localidade(sk_localidade),

    data_publicacao DATE,
    data_homologacao DATE,
    descricao_item TEXT,
    perfil_gasto VARCHAR(30),

    quantidade NUMERIC(20, 4)
        CHECK (quantidade IS NULL OR quantidade > 0),

    valor_unitario_estimado NUMERIC(20, 4)
        CHECK (valor_unitario_estimado IS NULL OR valor_unitario_estimado >= 0),

    valor_total_estimado NUMERIC(20, 2)
        CHECK (valor_total_estimado IS NULL OR valor_total_estimado >= 0),

    valor_unitario_homologado NUMERIC(20, 4)
        CHECK (valor_unitario_homologado IS NULL OR valor_unitario_homologado >= 0),

    valor_total_homologado NUMERIC(20, 2)
        CHECK (valor_total_homologado IS NULL OR valor_total_homologado >= 0),

    comparavel INTEGER NOT NULL CHECK (comparavel IN (0, 1)),

    economia_valor NUMERIC(20, 2),

    dias_ciclo INTEGER
        CHECK (dias_ciclo IS NULL OR dias_ciclo >= 0),

    CONSTRAINT chk_datas_contratacao
        CHECK (
            data_publicacao IS NULL
            OR data_homologacao IS NULL
            OR data_homologacao >= data_publicacao
        ),

    PRIMARY KEY (numero_controle_pncp, numero_item)
);
