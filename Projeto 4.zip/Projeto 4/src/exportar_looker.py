
import csv
from pathlib import Path

from src.banco import conectar

PASTA_RAIZ = Path(__file__).resolve().parents[1]
PASTA_SAIDA = PASTA_RAIZ / "data" / "processed" / "looker"

CONSULTAS = {
    "01_economia_geral": """
        SELECT
            SUM(CASE WHEN comparavel = 1
                THEN valor_total_estimado ELSE 0 END) AS estimado_comparavel,
            SUM(CASE WHEN comparavel = 1
                THEN valor_total_homologado ELSE 0 END) AS homologado_comparavel,
            SUM(CASE WHEN comparavel = 1
                THEN valor_total_estimado - valor_total_homologado
                ELSE 0 END) AS economia_valor,
            ROUND(
                100.0 * SUM(CASE WHEN comparavel = 1
                    THEN valor_total_estimado - valor_total_homologado
                    ELSE 0 END)
                / NULLIF(SUM(CASE WHEN comparavel = 1
                    THEN valor_total_estimado ELSE 0 END), 0),
                2
            ) AS economia_percentual
        FROM fato_item_contratado
    """,
    "02_fornecedores": """
        WITH total AS (
            SELECT SUM(valor_total_homologado) AS valor_total
            FROM fato_item_contratado
        )
        SELECT
            f.nome_fornecedor,
            SUM(ft.valor_total_homologado) AS volume_homologado,
            ROUND(
                100.0 * SUM(ft.valor_total_homologado)
                / NULLIF((SELECT valor_total FROM total), 0),
                2
            ) AS percentual_do_total
        FROM fato_item_contratado ft
        JOIN dim_fornecedor f
            ON ft.sk_fornecedor = f.sk_fornecedor
        GROUP BY f.ni_fornecedor, f.nome_fornecedor
        ORDER BY volume_homologado DESC
        LIMIT 10
    """,
    "03_modalidades": """
        SELECT
            m.nome_modalidade,
            SUM(ft.valor_total_homologado) AS volume_homologado,
            SUM(CASE WHEN ft.comparavel = 1
                THEN ft.valor_total_estimado ELSE 0 END)
                AS estimado_comparavel,
            SUM(CASE WHEN ft.comparavel = 1
                THEN ft.valor_total_estimado - ft.valor_total_homologado
                ELSE 0 END) AS economia_valor,
            ROUND(
                100.0 * SUM(CASE WHEN ft.comparavel = 1
                    THEN ft.valor_total_estimado - ft.valor_total_homologado
                    ELSE 0 END)
                / NULLIF(SUM(CASE WHEN ft.comparavel = 1
                    THEN ft.valor_total_estimado ELSE 0 END), 0),
                2
            ) AS economia_percentual
        FROM fato_item_contratado ft
        JOIN dim_modalidade m
            ON ft.sk_modalidade = m.sk_modalidade
        GROUP BY m.nome_modalidade
        ORDER BY volume_homologado DESC
    """,
    "04_ciclo_por_orgao": """
        SELECT
            o.nome_orgao,
            COUNT(ft.dias_ciclo) AS itens_com_ciclo,
            ROUND(AVG(ft.dias_ciclo), 1) AS media_dias_ciclo
        FROM fato_item_contratado ft
        JOIN dim_orgao o ON ft.sk_orgao = o.sk_orgao
        WHERE ft.dias_ciclo IS NOT NULL
        GROUP BY o.nome_orgao
        HAVING COUNT(ft.dias_ciclo) >= 5
        ORDER BY media_dias_ciclo DESC
    """,
    "05_despesas_por_estado": """
        SELECT
            l.uf_sigla,
            l.uf_nome,
            l.regiao,
            SUM(ft.valor_total_homologado) AS volume_homologado,
            ROUND(
                100.0 * SUM(CASE WHEN ft.comparavel = 1
                    THEN ft.valor_total_estimado - ft.valor_total_homologado
                    ELSE 0 END)
                / NULLIF(SUM(CASE WHEN ft.comparavel = 1
                    THEN ft.valor_total_estimado ELSE 0 END), 0),
                2
            ) AS economia_percentual
        FROM fato_item_contratado ft
        JOIN dim_localidade l
            ON ft.sk_localidade = l.sk_localidade
        GROUP BY l.uf_sigla, l.uf_nome, l.regiao
        ORDER BY volume_homologado DESC
    """,
    "06_despesas_por_regiao": """
        SELECT
            l.regiao,
            SUM(ft.valor_total_homologado) AS volume_homologado,
            ROUND(
                100.0 * SUM(CASE WHEN ft.comparavel = 1
                    THEN ft.valor_total_estimado - ft.valor_total_homologado
                    ELSE 0 END)
                / NULLIF(SUM(CASE WHEN ft.comparavel = 1
                    THEN ft.valor_total_estimado ELSE 0 END), 0),
                2
            ) AS economia_percentual
        FROM fato_item_contratado ft
        JOIN dim_localidade l
            ON ft.sk_localidade = l.sk_localidade
        GROUP BY l.regiao
        ORDER BY volume_homologado DESC
    """,
    "07_perfil_dos_gastos": """
        SELECT
            perfil_gasto,
            SUM(valor_total_homologado) AS volume_homologado,
            ROUND(
                100.0 * SUM(valor_total_homologado)
                / NULLIF((
                    SELECT SUM(valor_total_homologado)
                    FROM fato_item_contratado
                ), 0),
                2
            ) AS percentual_do_total
        FROM fato_item_contratado
        GROUP BY perfil_gasto
        ORDER BY volume_homologado DESC
    """,
}


def main():
    PASTA_SAIDA.mkdir(parents=True, exist_ok=True)
    conexao = conectar()

    try:
        with conexao.cursor() as cursor:
            for nome, consulta in CONSULTAS.items():
                cursor.execute(consulta)
                colunas = [item[0] for item in cursor.description]
                linhas = cursor.fetchall()
                destino = PASTA_SAIDA / f"{nome}.csv"

                with destino.open(
                    "w", newline="", encoding="utf-8-sig"
                ) as arquivo:
                    escritor = csv.writer(arquivo)
                    escritor.writerow(colunas)
                    escritor.writerows(linhas)

                print(f"{destino.name}: {len(linhas)} linhas exportadas")

    finally:
        conexao.close()

    print("\nExportação concluída.")


if __name__ == "__main__":
    main()
